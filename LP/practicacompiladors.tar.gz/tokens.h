#ifndef tokens_h
#define tokens_h
/* tokens.h -- List of labelled tokens and stuff
 *
 * Generated from: practica.g
 *
 * Terence Parr, Will Cohen, and Hank Dietz: 1989-2001
 * Purdue University Electrical Engineering
 * ANTLR Version 1.33MR33
 */
#define zzEOF_TOKEN 1
#define CHATBOT 2
#define THEN 3
#define OR 4
#define END 5
#define INTERACTION 6
#define CONVERSATION 7
#define QT 8
#define ANSWERS 9
#define NUM 10
#define WORD 11
#define SPACE 12
#define COLON 13
#define SEMICOLON 14
#define QMARK 15
#define HASH 16
#define LEFTBRAKET 17
#define RIGHTBRAKET 18
#define LEFTPAR 19
#define RIGHTPAR 20
#define COMA 21
#define ARROW 22

#ifdef __USE_PROTOS
void chatbot(AST**_root);
#else
extern void chatbot();
#endif

#ifdef __USE_PROTOS
void part(AST**_root);
#else
extern void part();
#endif

#ifdef __USE_PROTOS
void question(AST**_root);
#else
extern void question();
#endif

#ifdef __USE_PROTOS
void listwords(AST**_root);
#else
extern void listwords();
#endif

#ifdef __USE_PROTOS
void justoneanswer(AST**_root);
#else
extern void justoneanswer();
#endif

#ifdef __USE_PROTOS
void answer(AST**_root);
#else
extern void answer();
#endif

#ifdef __USE_PROTOS
void typeanswer1(AST**_root);
#else
extern void typeanswer1();
#endif

#ifdef __USE_PROTOS
void typeanswer2(AST**_root);
#else
extern void typeanswer2();
#endif

#ifdef __USE_PROTOS
void conversation(AST**_root);
#else
extern void conversation();
#endif

#ifdef __USE_PROTOS
void conversations(AST**_root);
#else
extern void conversations();
#endif

#ifdef __USE_PROTOS
void startchat(AST**_root);
#else
extern void startchat();
#endif

#ifdef __USE_PROTOS
void op(AST**_root);
#else
extern void op();
#endif

#ifdef __USE_PROTOS
void chat(AST**_root);
#else
extern void chat();
#endif

#ifdef __USE_PROTOS
void chats(AST**_root);
#else
extern void chats();
#endif

#ifdef __USE_PROTOS
void inner(AST**_root);
#else
extern void inner();
#endif

#ifdef __USE_PROTOS
void par(AST**_root);
#else
extern void par();
#endif

#endif
extern SetWordType zzerr1[];
extern SetWordType zzerr2[];
extern SetWordType zzerr3[];
extern SetWordType setwd1[];
extern SetWordType setwd2[];
extern SetWordType zzerr4[];
extern SetWordType setwd3[];
