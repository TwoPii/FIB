/*
 * A n t l r  S e t s / E r r o r  F i l e  H e a d e r
 *
 * Generated from: practica.g
 *
 * Terence Parr, Russell Quong, Will Cohen, and Hank Dietz: 1989-2001
 * Parr Research Corporation
 * with Purdue University Electrical Engineering
 * With AHPCRC, University of Minnesota
 * ANTLR Version 1.33MR33
 */

#define ANTLR_VERSION	13333
#include "pcctscfg.h"
#include "pccts_stdio.h"

#include <string>
#include <iostream>
#include <cstdlib>

using namespace std;

// struct to store information about tokens
typedef struct {
  string kind;
  string text;
} Attrib;


// function to fill token information (predeclaration)
void zzcr_attr(Attrib *attr, int type, char *text);

// fields for AST nodes
#define AST_FIELDS string kind; string text;
#include "ast.h"

// macro to create a new AST node (and function predeclaration)
#define zzcr_ast(as,attr,ttype,textt) as=createASTnode(attr,ttype,textt)
AST* createASTnode(Attrib* attr, int ttype, char *textt);
#define zzSET_SIZE 4
#include "antlr.h"
#include "ast.h"
#include "tokens.h"
#include "dlgdef.h"
#include "err.h"

ANTLRChar *zztokens[23]={
	/* 00 */	"Invalid",
	/* 01 */	"@",
	/* 02 */	"CHATBOT",
	/* 03 */	"THEN",
	/* 04 */	"OR",
	/* 05 */	"END",
	/* 06 */	"INTERACTION",
	/* 07 */	"CONVERSATION",
	/* 08 */	"QT",
	/* 09 */	"ANSWERS",
	/* 10 */	"NUM",
	/* 11 */	"WORD",
	/* 12 */	"SPACE",
	/* 13 */	"COLON",
	/* 14 */	"SEMICOLON",
	/* 15 */	"QMARK",
	/* 16 */	"HASH",
	/* 17 */	"LEFTBRAKET",
	/* 18 */	"RIGHTBRAKET",
	/* 19 */	"LEFTPAR",
	/* 20 */	"RIGHTPAR",
	/* 21 */	"COMA",
	/* 22 */	"ARROW"
};
SetWordType zzerr1[4] = {0x80,0x3,0x0,0x0};
SetWordType zzerr2[4] = {0x0,0x4,0x8,0x0};
SetWordType zzerr3[4] = {0x0,0x4,0xa,0x0};
SetWordType setwd1[23] = {0x0,0x1,0x56,0x0,0x0,0x0,0x56,
	0x0,0x0,0x0,0xb0,0x56,0x0,0x0,0x8,
	0x8,0x0,0x0,0x10,0xb0,0x8,0x10,0x0};
SetWordType setwd2[23] = {0x0,0x10,0x6f,0x0,0x0,0x0,0xef,
	0x0,0x0,0x0,0x0,0x7,0x0,0x0,0x0,
	0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0};
SetWordType zzerr4[4] = {0x0,0x0,0x9,0x0};
SetWordType setwd3[23] = {0x0,0x0,0x3,0x3,0x3,0x0,0x3,
	0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
	0x0,0x0,0x0,0x0,0x0,0x3,0x0,0x0};
