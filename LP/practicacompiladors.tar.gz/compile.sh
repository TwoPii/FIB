antlr -gt practica.g
dlg -ci parser.dlg scan.c
g++ -o practica practica.c scan.c err.c -w
