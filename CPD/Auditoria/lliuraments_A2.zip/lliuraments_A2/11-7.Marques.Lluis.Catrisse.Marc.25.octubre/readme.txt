11-7.Marques.Lluis.Catrisse.Marc.25.octubre --> fitxer amb el treball en si
calcul_electricitat_i_NSP --> Fitxer amb el calcul de consum de electricitat
cost --> Excel amb els calculs de cost de cada pe�a, internet, consum i total (desglo�at)
nodeStorage --> document on es poden veure totes les especificacions del node de Storage segons thinkmate
nodeVM --> document on es poden veure totes les especificacions del node de VM segons thinkmate
PowerCalc_Catalyst_3850_10-18-2018 --> Calcul de consum dels Switch Catalyst 3850
PowerCalc_Cisco_Nexus_7000_10-19-2018 --> Calcul de consum dels Switch Nexus serie 7000+ de agregaci�
PowerCalc_Cisco_Nexus_7000TOP --> Calcul de consum del Switch Nexus serie 7000+ de TOP (el switch que connecta a l'exterior)


