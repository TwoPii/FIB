#include <heap.h>
#include <sched.h>
#include <mm_address.h>

void* HEAPSTART = (void*)(L_USER_START + (NUM_PAG_CODE + NUM_PAG_DATA*2)*PAGE_SIZE);
struct heap heap[NR_TASKS];

void init_heap()
{
	int i;
	for(i = 0; i < NR_TASKS; i++) {
		heap[i].heapsize = -1;
	}
}

struct heap *allocate_heap()
{
	int i;
	for(i = 0; i < NR_TASKS; i++) {
		if (heap[i].heapsize == -1) {
			heap[i].heapsize = 0;
			return &heap[i];
		}
	}
	return (struct heap*) 0;
}

void free_heap(struct heap *h) 
{
	if (h==NULL) return;
	h->heapsize = -1;
}
