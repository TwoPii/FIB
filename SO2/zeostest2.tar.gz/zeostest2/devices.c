#include <io.h>
#include <utils.h>
#include <list.h>
#include <sched.h>
#include <circular_buffer.h>

// Queue for blocked processes in I/O 
struct list_head blocked;
struct circular_buffer b;
int remaining_chars = 0;

int sys_write_console(char *buffer,int size)
{
  int i;
  
  for (i=0; i<size; i++)
    printc(buffer[i]);
  
  return size;
}

int sys_read_keyboard(char *buffer, int size)
{
	if (!list_empty(&keyboardqueue)) {
		block_process(&keyboardqueue, AT_END);
	}
	remaining_chars = size;
	int r = cb_get_to_user(&b, remaining_chars, buffer);
	remaining_chars -= r;
	buffer += r;
	while (remaining_chars > 0) {
		block_process(&keyboardqueue, AT_BEGINNING);
		r = cb_get_to_user(&b, remaining_chars, buffer);
		remaining_chars -= r;
		buffer += r;
	}
	return size;
}

