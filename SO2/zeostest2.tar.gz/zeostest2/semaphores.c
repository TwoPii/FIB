#include <list.h>
#include <errno.h>
#include <sched.h>

#define MAX_SEM 20

struct semaphore {
	int counter;
	int owner;
	struct list_head blocked;
};

struct semaphore sems[MAX_SEM];

void init_semaphores()
{
	int i;
	for(i=0; i<MAX_SEM; i++) {
		sems[i].owner = -1;
		INIT_LIST_HEAD(&sems[i].blocked);
	}
}

int sys_sem_init(int n_sem, unsigned int value)
{
	if ((n_sem<0) || (n_sem>=MAX_SEM)) return -EBADF;
	if (sems[n_sem].owner != -1) return -EPERM; //Already init 
	sems[n_sem].owner = current()->PID;
	sems[n_sem].counter = value;
	return 0;
}

int sys_sem_wait(int n_sem)
{
	if ((n_sem<0) || (n_sem>=MAX_SEM)) return -EBADF;
	if (sems[n_sem].owner == -1) return -EBADF;	//Already dead
	
	if (sems[n_sem].counter <=0) {
		update_process_state_rr(current(), &sems[n_sem].blocked);
		sched_next_rr();
		if (sems[n_sem].owner == -1) return -1;
	} else {
		sems[n_sem].counter --;
	}
		
	return 0;
}

int sys_sem_signal(int n_sem)
{
	if ((n_sem<0) || (n_sem>=MAX_SEM)) return -EBADF;
	if (sems[n_sem].owner == -1) return -EBADF;	//Already dead

	if (list_empty(&sems[n_sem].blocked)) {
		sems[n_sem].counter ++;
	} else {
		struct list_head *e = list_first(&sems[n_sem].blocked);
		struct task_struct *p = list_head_to_task_struct(e);
		update_process_state_rr(p, &readyqueue);
	}
	return 0;
}

int sys_sem_destroy(int n_sem)
{
	if ((n_sem<0) || (n_sem>=MAX_SEM)) return -EBADF;
	if (sems[n_sem].owner == -1) return -EBADF;	//Already dead
	if (current()->PID != sems[n_sem].owner) return -EPERM;
	struct list_head *e;
	struct list_head *tmp;
	list_for_each_safe(e, tmp, &sems[n_sem].blocked) {
		struct task_struct* p = list_head_to_task_struct(e);
		update_process_state_rr(p, &readyqueue);
	}
	sems[n_sem].owner = -1;
	return 0;
}


