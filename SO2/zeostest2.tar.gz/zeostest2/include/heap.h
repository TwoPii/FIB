#ifndef _HEAP_H__
#define _HEAP_H__

struct heap {
	int heapsize;
};

extern void* HEAPSTART;

void init_heap();
struct heap *allocate_heap();
void free_heap(struct heap *h);

#endif /* _HEAP_H__ */
