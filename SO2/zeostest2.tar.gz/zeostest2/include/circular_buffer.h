#ifndef _CIRCULAR_BUFFER_H__
#define _CIRCULAR_BUFFER_H__

#define MAX	5
struct circular_buffer{
	char bytes[MAX];
	int write;	// Writer index
	int read;	// Reader index
	int num;	// Number of chars inside 'bytes' (REDUNDANT)
};

int cb_init(struct circular_buffer* b);
int cb_push(struct circular_buffer* b, char c);
int cb_get(struct circular_buffer* b, int size, char *buff) ;
int cb_get_to_user(struct circular_buffer* b, int size, char *buff) ;
int cb_size(struct circular_buffer* b);
int cb_is_full(struct circular_buffer *b);
#endif /* _CIRCULAR_BUFFER_H__ */
