#ifndef _SEMAPHORES_H__
#define _SEMAPHORES_H__

void init_semaphores();

int sem_init(int n_sem, unsigned int value);
int sem_wait(int n_sem);
int sem_signal(int n_sem);
int sem_destroy(int n_sem);

#endif /* _SEMAPHORES_H__ */
