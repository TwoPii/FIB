#include <utils.h>
#include <circular_buffer.h>

int cb_init(struct circular_buffer* b)
{
	b->write = 0;
	b->read = 0;
	b->num = 0;	
	return 1;
}

int cb_push(struct circular_buffer* b, char c)
{
	if (!(b->num < MAX)) return 0;
	b->bytes[b->write++] = c;
	b->write %= MAX;
	b->num ++;
	return 1;
}

int cb_get(struct circular_buffer* b, int size, char *buff) 
{
	int max = size;
	int i = 0;
	if (max == 0) return 0;
	if (max > b->num) { max = b->num;}

	i = 0;
	while(i < max) {
		buff[i++] = b->bytes[b->read++];
		b->read %= MAX;
		b->num --;
	}
	return max;
}

int cb_get_to_user(struct circular_buffer* b, int size, char *buff) 
{
	if (size == 0) return 0;
	int max = size;
	if (max > b->num) { max = b->num;}

	/* 	a) R***W__MAX
		b) *W___R*MAX 
		d) ***R***MAX
			W				 */

	int remain = size;
	int first = MAX - b->read;
	if (first > max) {
		first = max;
	}
	remain -= first;
	copy_to_user(&b->bytes[b->read], buff, first);
	copy_to_user(&b->bytes[0], buff+first, remain);
	b->read += max;
	b->read %= MAX;
	b->num -= max;
	return max;
}

int cb_size(struct circular_buffer* b)
{
	return b->num;
}

int cb_is_full(struct circular_buffer *b) 
{
	return (b->num == MAX);
}
