#include <libc.h>

#define WRITE(s) write(1, (s), strlen(s))

void mytestsbrk2PAGES()
{
	void *init;
	void *res;
	WRITE("\n====Check increasing memory(2 pages)\n");
	init = sbrk(0);
	sbrk(0x1000);
	sbrk(0x1000);
	sbrk(-0x1000);
	sbrk(-0x1000);
	res = sbrk(0);
	if (res != init) { WRITE("OOps, there is some memory leak\n");}
	else { WRITE("OK - Life is good\n");}
}

int __attribute__ ((__section__(".text.main")))
  main(void)
{
	/* Next line, tries to move value 0 to CR3 register. This register is a privileged one, and so it will raise an exception */
	/* __asm__ __volatile__ ("mov %0, %%cr3"::"r" (0) ); */

	mytestsbrk2PAGES();
	while (1);
}
