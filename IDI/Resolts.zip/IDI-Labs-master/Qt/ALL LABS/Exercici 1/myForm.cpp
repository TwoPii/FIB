#include "myForm.h"

myForm::myForm(QWidget* parent): QWidget(parent) {
	ui.setupUi(this);
	// connect(ui.cero, SIGNAL(clicked()), ui.horitzontalSlider, SLOT(cero());
}