Qt
==

Laboratori de QT assignatura de IDI
