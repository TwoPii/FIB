# IDI Labs

In the autumn four-month period of the 2015/2016 course, I studied a subject called **Interaction and Design Interfaces** (IDI) at FIB (BarcelonaTech).

On this subject, I did lab sessions each week where I learned **OpenGL** and **Qt** basic concepts. On the OpenGL Labs I learnt to represent 3D figures like **Homer**'s and **Patricio**'s and more things. And on the Qt Labs I learnt to create and design interfaces with Qt Designer, and also I learnt the mechanism of **slots**.

As I like to share all my labor done, I leave the repository with all I managed to do here.

**Thank you** very much for your time!

![](https://github.com/AlbertSuarez/IDI-Labs/blob/master/images/image1.png?raw=true)

![](https://github.com/AlbertSuarez/IDI-Labs/blob/master/images/image2.png?raw=true)

![](https://github.com/AlbertSuarez/IDI-Labs/blob/master/images/image3.png?raw=true)

![](https://github.com/AlbertSuarez/IDI-Labs/blob/master/images/image4.png?raw=true)

![](https://github.com/AlbertSuarez/IDI-Labs/blob/master/images/image5.png?raw=true)

