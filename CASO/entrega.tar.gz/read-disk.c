#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <string.h>
#include <errno.h>
#include <sys/file.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>

#define MBYTES 1024

int main(){

	struct timeval tv0, tv1;
	double secs;
	int res;
	int fd;
	char c[1024*1024]; // 1MByte

	fd = open("/tmp/file-sdb", O_RDWR|O_CREAT,S_IRUSR|S_IWUSR);

	res = gettimeofday(&tv0, NULL);
	if(res < 0) perror("gettimeofday");
	
	for(int i = 0; i < MBYTES; i++) pread(fd, &c, 1024*1024, 1024*1024*i);


	res = gettimeofday(&tv1, NULL);
	if(res < 0) perror("gettimeofday");

	close(fd);

	secs = (((double)tv1.tv_sec*1000000.0 + (double)tv1.tv_usec) - ((double)tv0.tv_sec*1000000.0 + (double)tv0.tv_usec))/1000000.0;

	printf("-----------------DISK NOU----------------");
	printf("Temps: %lf segons\n", secs); // Obtenim el temps
	double bandwith;
	bandwith = (MBYTES*1024)/secs;
	printf("Bandwith: %lf Kbps, %lf KBytes/segon, %lf MBYTES/segon, %lf GBytes/segon \n",(bandwith*8),(bandwith),(bandwith/1024), bandwith/(1024*1024));


//==================================================================================

	fd = open("/mnt/point/file-sdc", O_RDWR|O_CREAT,S_IRUSR|S_IWUSR);

	res = gettimeofday(&tv0, NULL);
	if(res < 0) perror("gettimeofday");

	
	for(int i = 0; i < MBYTES; i++) pread(fd, &c, 1024*1024, 1024*1024*i);


	res = gettimeofday(&tv1, NULL);
	if(res < 0) perror("gettimeofday");

	close(fd);

	secs = (((double)tv1.tv_sec*1000000.0 + (double)tv1.tv_usec) - ((double)tv0.tv_sec*1000000.0 + (double)tv0.tv_usec))/1000000.0;

	printf("-----------------DISK ANTIC----------------");
	printf("Temps: %lf segons\n", secs); // Obtenim el temps
	bandwith = (MBYTES*1024)/secs;
	printf("Bandwith: %lf Kbps, %lf KBytes/segon, %lf MBYTES/segon, %lf GBytes/segon \n",(bandwith*8),(bandwith),(bandwith/1024), bandwith/(1024*1024)); 
}
