#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <time.h>
#include <sched.h>

#define ITER 10000000

int main(int argc, char * argv [])
{
   int res;
   void *p;
   struct timespec ts0, ts1;
   double secs;
   double secsacum;


   if (argc > 1) {
      fprintf(stderr, "Us: %s\n", argv[0]);
      exit(1);
   }

   /* Fake call to warm-up */
   res = clock_gettime(CLOCK_REALTIME, &ts0);
   if (res < 0) { 
      perror ("clock_gettime");
   }
   /* Fake call to warm-up */
   usleep(100);

   printf ("------------------------START---------------------------- \n");
  
   printf ("Testing SBRK(0) syscall execution time. \n");
   for (int i = 0; i < ITER; i++) {
	   res = clock_gettime(CLOCK_REALTIME, &ts0);
	   if (res < 0) { 
	      perror ("clock_gettime");
	   }

	   p = sbrk(0);

	   res = clock_gettime(CLOCK_REALTIME, &ts1);
	   if (res < 0) {
	      perror ("clock_gettime");
	   }

	   // correct formula!!
	   secs = (((double)ts1.tv_sec*1000000000.0 + (double)ts1.tv_nsec) - 
		  ((double)ts0.tv_sec*1000000000.0 + (double)ts0.tv_nsec))/1000000000.0;

	   secsacum = secsacum + secs;
   }
   printf (" SBRK(0) took %.8lf seconds.\n", secsacum/ITER);

   printf ("Testing SBRK(inc) syscall execution time. \n");
   for (int i = 0; i < ITER; i++) {
	   res = clock_gettime(CLOCK_REALTIME, &ts0);
	   if (res < 0) { 
	      perror ("clock_gettime");
	   }

	   p = sbrk(1000000);

	   res = clock_gettime(CLOCK_REALTIME, &ts1);
	   if (res < 0) {
	      perror ("clock_gettime");
	   }

	   // correct formula!!
	   secs = (((double)ts1.tv_sec*1000000000.0 + (double)ts1.tv_nsec) - 
		  ((double)ts0.tv_sec*1000000000.0 + (double)ts0.tv_nsec))/1000000000.0;

	   secsacum = secsacum + secs;
   }
   printf (" SBRK(inc) took %.8lf seconds.\n", secsacum/ITER);

   printf ("Testing SCHED_YIELD syscall execution time. \n");
   for (int i = 0; i < ITER; i++) {
	   res = clock_gettime(CLOCK_REALTIME, &ts0);
	   if (res < 0) { 
	      perror ("clock_gettime");
	   }

	   sched_yield();

	   res = clock_gettime(CLOCK_REALTIME, &ts1);
	   if (res < 0) {
	      perror ("clock_gettime");
	   }

	   // correct formula!!
	   secs = (((double)ts1.tv_sec*1000000000.0 + (double)ts1.tv_nsec) - 
		  ((double)ts0.tv_sec*1000000000.0 + (double)ts0.tv_nsec))/1000000000.0;

	   secsacum = secsacum + secs;
   }
   printf (" SCHED_YIELD took %.8lf seconds.\n", secsacum/ITER);

   printf ("Testing GETPID syscall execution time. \n");
   for (int i = 0; i < ITER; i++) {
           int ret;
	   res = clock_gettime(CLOCK_REALTIME, &ts0);
	   if (res < 0) { 
	      perror ("clock_gettime");
	   }

	   ret = getpid();

	   res = clock_gettime(CLOCK_REALTIME, &ts1);
	   if (res < 0) {
	      perror ("clock_gettime");
	   }

	   // correct formula!!
	   secs = (((double)ts1.tv_sec*1000000000.0 + (double)ts1.tv_nsec) - 
		  ((double)ts0.tv_sec*1000000000.0 + (double)ts0.tv_nsec))/1000000000.0;

	   secsacum = secsacum + secs;
   }
   printf (" GETPID took %.8lf seconds.\n", secsacum/ITER);

   printf ("Testing FORK/WAITPID syscall execution time. \n");
   for (int i = 0; i < ITER/1000; i++) {
	   int ret;
	   res = clock_gettime(CLOCK_REALTIME, &ts0);
	   if (res < 0) { 
	      perror ("clock_gettime");
	   }

	   if(fork() == 0) exit(0); //Fill
	   waitpid(-1, NULL, WNOHANG); //quasevol Fill

	   res = clock_gettime(CLOCK_REALTIME, &ts1);
	   if (res < 0) {
	      perror ("clock_gettime");
	   }

	   // correct formula!!
	   secs = (((double)ts1.tv_sec*1000000000.0 + (double)ts1.tv_nsec) - 
		  ((double)ts0.tv_sec*1000000000.0 + (double)ts0.tv_nsec))/1000000000.0;

	   secsacum = secsacum + secs;
   }
   printf (" FORK/WAITPID took %.8lf seconds.\n", secsacum/(ITER/1000) );



   printf ("-------------------------END----------------------------- \n");
}
