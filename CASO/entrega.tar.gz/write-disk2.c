#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <strings.h>
#include <string.h>
#include <errno.h>
#include <sys/file.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <sys/mman.h>

#define MBYTES 1024

int main(){

	struct timeval tv0, tv1;
	double secs;
	int res;
	int fd;
	char * mappedData;
	int size;

	size = MBYTES*1024*1024; //1 GByte

//=============================NEW DISK===========================================

	//2GB file created with: ~/Documents/exemple-rendiment$ fallocate -l 2G file2G
	fd = open("/home/genisjosep/Documents/exemple-rendiment/file2G", O_CREAT | O_RDWR, 0644);
	
	if(fd >= 0) {
		//map fd file to address specified by the first parameter
		mappedData = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
		printf ("file mapped to address 0x%lx\n", (unsigned long) mappedData);
	}
	if(fd < 0 || mappedData == MAP_FAILED) {
		perror("error mapping data");
		exit(1);
	}

	res = gettimeofday(&tv0, NULL);
	if(res < 0) perror("gettimeofday");
	
	//escrivim al disc directament al escriure a una regió de disc mapejada a memòria
	for(unsigned long i = 0; i < size; i++) mappedData [i] = 'A';

	res = gettimeofday(&tv1, NULL);
	if(res < 0) perror("gettimeofday");
		
	close(fd);

	secs = (((double)tv1.tv_sec*1000000.0 + (double)tv1.tv_usec) - ((double)tv0.tv_sec*1000000.0 + (double)tv0.tv_usec))/1000000.0;

	printf("-----------------DISK NOU----------------");
	printf("Temps: %lf segons\n", secs); // Obtenim el temps
	double bandwith;
	bandwith = (MBYTES*1024)/secs; //in KB
	printf("Bandwith: %lf Kbps, %lf KBytes/segon, %lf MBYTES/segon, %lf GBytes/segon \n",(bandwith*8),(bandwith),(bandwith/1024), bandwith/(1024*1024));




//=============================OLD DISK===========================================
/*
	//2GB file created with: /mnt/point/$ fallocate -l 2G file2G
	fd = open("/mnt/point/file2G", O_CREAT | O_RDWR, 0644);
	
	if(fd >= 0) {
		//map fd file to address specified by the first parameter
		mappedData = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
		printf ("file from old disk mapped to address 0x%lx\n", (unsigned long) mappedData);
	}
	if(fd < 0 || mappedData == MAP_FAILED) {
		perror("error when mapping data");
		exit(1);
	}

	res = gettimeofday(&tv0, NULL);
	if(res < 0) perror("gettimeofday");
	
	//escrivim al disc directament al escriure a una regió de disc mapejada a memòria
	for(unsigned long i = 0; i < size; i++) mappedData [i] = 'A';

	res = gettimeofday(&tv1, NULL);
	if(res < 0) perror("gettimeofday");
		
	close(fd);
	secs = (((double)tv1.tv_sec*1000000.0 + (double)tv1.tv_usec) - ((double)tv0.tv_sec*1000000.0 + (double)tv0.tv_usec))/1000000.0;

	printf("-----------------DISK ANTIC----------------");
	printf("Temps: %lf segons\n", secs); // Obtenim el temps
	bandwith = (MBYTES*1024)/secs;
	printf("Bandwith: %lf Kbps, %lf KBytes/segon, %lf MBYTES/segon, %lf GBytes/segon \n",(bandwith*8),(bandwith),(bandwith/1024), bandwith/(1024*1024));

*/

}
