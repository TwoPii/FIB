/*
 * sched.c - initializes struct for task 0 anda task 1
 */

#include <sched.h>
#include <mm.h>
#include <io.h>

union task_union task[NR_TASKS]
  __attribute__((__section__(".data.task")));

#if 0
struct task_struct *list_head_to_task_struct(struct list_head *l)
{
  return list_entry( l, struct task_struct, list);
}
#endif

extern struct list_head blocked;
int PIDS = 1;

#define DEFAULT_QUANTUM 10

/* get_DIR - Returns the Page Directory address for task 't' */
page_table_entry * get_DIR (struct task_struct *t) 
{
	return t->dir_pages_baseAddr;
}

/* get_PT - Returns the Page Table address for task 't' */
page_table_entry * get_PT (struct task_struct *t) 
{
	return (page_table_entry *)(((unsigned int)(t->dir_pages_baseAddr->bits.pbase_addr))<<12);
}

struct task_struct *list_head_to_task_struct(struct list_head *l)
{	
	unsigned int ls;
	ls = (unsigned int)l&0xfffff000;
	return (struct task_struct*) ls;	
}



void init_stats(struct stats *s)
{

	s->user_ticks = 0;

	s->system_ticks = 0;

	s->blocked_ticks = 0;

	s->ready_ticks = 0;

	s->elapsed_total_ticks = get_ticks();

	s->total_trans = 0;

	s->remaining_ticks = get_ticks();

}

int allocate_DIR(struct task_struct *t) 
{
	int pos;

	pos = ((int)t-(int)task)/sizeof(union task_union);

	t->dir_pages_baseAddr = (page_table_entry*) &dir_pages[pos]; 

	return 1;
}

void cpu_idle(void)
{
	__asm__ __volatile__("sti": : :"memory");

	while(1)
	{
	;
	}
}

int remaining_quantum=0;

int get_quantum(struct task_struct *t){
	return t->total_quantum;
}

void set_quantum(struct task_struct *t, int new_quantum){
	t->total_quantum = new_quantum;
}

void update_sched_data_rr(void){
	remaining_quantum--;
}

int needs_sched_rr(void){
	if ((remaining_quantum==0)&&(!list_empty(&ready_queue))) return 1;
	if (remaining_quantum==0) remaining_quantum=get_quantum(current());
	return 0;
}

void update_process_state_rr(struct task_struct *t, struct list_head *dst_queue){
	if (t->state!=ST_RUN) list_del(&(t->list));
	if (dst_queue!=NULL) {
	    list_add_tail(&(t->list), dst_queue);
	    if (dst_queue!=&ready_queue) t->state=ST_BLOCKED;
	    else{
          unsigned long current_ticks = get_ticks();
          t->task_stats.system_ticks += current_ticks-t->task_stats.elapsed_total_ticks; //runsystem-ready
          t->task_stats.elapsed_total_ticks = current_ticks;
	      t->state=ST_READY;
	    }
	}
	else t->state=ST_RUN;
}

struct task_struct *idle_task=NULL;

void sched_next_rr(void){
  struct list_head *e;
  struct task_struct *t;
  if (!list_empty(&ready_queue)) {
	e = list_first(&ready_queue);
    list_del(e);

    t=list_head_to_task_struct(e);
  }
  else t=idle_task;

  t->state=ST_RUN;
  remaining_quantum=get_quantum(t);
  unsigned long current_ticks = get_ticks();
  
  current()->task_stats.system_ticks += current_ticks-current()->task_stats.elapsed_total_ticks; //runsystem-ready
  current()->task_stats.elapsed_total_ticks = current_ticks;
  
  t->task_stats.ready_ticks += current_ticks-t->task_stats.elapsed_total_ticks; //ready-runsystem
  t->task_stats.elapsed_total_ticks = current_ticks;
  
  
  t->task_stats.total_trans++;
  
  task_switch((union task_union*)t);
}

void schedule(){
  update_sched_data_rr();
  if (needs_sched_rr())
  {
    update_process_state_rr(current(), &ready_queue);
    sched_next_rr();
  }
}
void init_idle (void)
{
	//get available task_struct freequeue
	struct list_head * firstelem = list_first(&free_queue);
	list_del(firstelem); 
	struct task_struct *idle = list_head_to_task_struct(firstelem);

	//assign pid 0
	idle->PID = 0;
	idle->total_quantum=DEFAULT_QUANTUM;
	//dir_pages_baseAddr new dir
	allocate_DIR(idle);

    init_stats(&idle->task_stats);
    
	//stack[max] = &cpu_idle stack[max-1] = 0x0 añadir campo kernel_esp en pcb
	union task_union *idleunion = (union task_union*) idle;
	idleunion->stack[KERNEL_STACK_SIZE - 1] = (unsigned long) &cpu_idle;
	idleunion->stack[KERNEL_STACK_SIZE - 2] = 0;
	idle->kernel_esp = (int)&(idleunion->stack[KERNEL_STACK_SIZE - 2]);

	//initialize apuntando al task_struct idle
	idle_task = idle;
}

void init_task1(void)
{
	//get available task_struct freequeue
	struct list_head * firstelem = list_first(&free_queue);
	list_del(firstelem); 
	struct task_struct *init = list_head_to_task_struct(firstelem);
	union task_union *initunion = (union task_union*) init;
	init->PID = 1;
	init->total_quantum=DEFAULT_QUANTUM;
    remaining_quantum=init->total_quantum;
	init->state=ST_RUN;
	allocate_DIR(init);

    init_stats(&init->task_stats);
    
	//set_user_pages
	set_user_pages(init);

	//update TSS to point new_task system stack. modify MSR 0x175
	unsigned long esp = (unsigned long) &(initunion->stack[KERNEL_STACK_SIZE]); 
	tss.esp0 = esp;
	writeMSR(0x175,0,esp);

	//set page directory as current page directory (set_cr3)
	set_cr3(init->dir_pages_baseAddr);
}


void init_sched(){
	
	INIT_LIST_HEAD(&ready_queue);
	INIT_LIST_HEAD(&free_queue);
	int i;
	for(i = 0; i < NR_TASKS; i++){
		list_add(&(task[i].task.list), &free_queue);
	}
}

struct task_struct* current()
{
  int ret_value;
  
  __asm__ __volatile__(
  	"movl %%esp, %0"
	: "=g" (ret_value)
  );
  return (struct task_struct*)(ret_value&0xfffff000);
}

void inner_task_switch(union task_union *new)
{
  page_table_entry *new_DIR = get_DIR(&new->task);
  set_cr3(new_DIR);
  tss.esp0=(int)&(new->stack[KERNEL_STACK_SIZE]);
  writeMSR(0x175,0,(unsigned long)&(new->stack[KERNEL_STACK_SIZE]));
  task_switch_assembler(&current()->kernel_esp, new->task.kernel_esp);
}


