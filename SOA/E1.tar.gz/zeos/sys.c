/*
 * sys.c - Syscalls implementation
 */
#include <devices.h>

#include <utils.h>

#include <io.h>

#include <mm.h>

#include <mm_address.h>

#include <sched.h>

#include "errno.h"

#define LECTURA 0
#define ESCRIPTURA 1

extern int zeos_ticks;
extern int PIDS;
extern int remaining_quantum;

int check_fd(int fd, int permissions)
{
  if (fd!=1) return -9; /*EBADF*/
  if (permissions!=ESCRIPTURA) return -13; /*EACCES*/
  return 0;
}

int ret_from_fork(){
	return 0;
}


int sys_ni_syscall()
{
	return -38; /*ENOSYS*/
}

int sys_getpid()
{
	return current()->PID;
}


int sys_write(int fd,char *buffer,int size){ 

	int retorn = check_fd(fd,ESCRIPTURA);
	if (retorn != 0) return retorn;
	else if (size <= 0 || buffer == NULL) return -EINVAL;
	
	char buff[size];
	retorn = copy_from_user(buffer, buff, size);
	if (retorn != 0) return retorn;
	
	retorn = sys_write_console(buff,size);
	return retorn;
	
}


int sys_fork()

{

	if(list_empty(&free_queue)) return -102;
	struct list_head* t1 = list_first(&free_queue);
	list_del(t1); 
	struct task_struct *son = list_head_to_task_struct(t1);
	union task_union * uson = (union task_union *) son;
	copy_data(current(), uson, sizeof(union task_union));
	allocate_DIR(uson);
    
    int pag[NUM_PAG_DATA];

    
   	page_table_entry * pt = get_PT (son);


    for(int i = 0; i < NUM_PAG_DATA; i++){ //20 frames fisicos para data hijo

		pag[i] = alloc_frame();

		if(pag[i] == -1) return -103;

		else set_ss_pag(pt,PAG_LOG_INIT_DATA+i,pag[i]);
	}

	
 	for(int i = 0; i < NUM_PAG_KERNEL; i++){ //asignar mismas direcciones logicas a fisicas kernel

		set_ss_pag(pt,i, get_frame(get_PT(current()),i));

	}
	
	for(int i = PAG_LOG_INIT_CODE; i < PAG_LOG_INIT_CODE+NUM_PAG_CODE; i++){ // asignar mismas direcciones logicas a fisicas codigo

		set_ss_pag(pt,i, get_frame(get_PT(current()),i));

	}
	
	for(int i = NUM_PAG_KERNEL+NUM_PAG_CODE; i < NUM_PAG_DATA+NUM_PAG_KERNEL+NUM_PAG_CODE; i++){ // copiar datos padre a hijo

		set_ss_pag(get_PT(current()), i+NUM_PAG_DATA, get_frame(pt, i)); //mapeo 1 frame de data de hijo a pt padre

		copy_data((void*)(i << 12), (void*)((i+NUM_PAG_DATA)<<12) , PAGE_SIZE);

		del_ss_pag(get_PT(current()), i+NUM_PAG_DATA);  

	}
	
    set_cr3(get_DIR(current()));	
    PIDS++;
    son->PID = PIDS;
    init_stats(&son->task_stats);
    son->state=ST_READY;
    int register_ebp;
    __asm__ __volatile__(

		"movl %%ebp, %0"

		:"=g" (register_ebp) //pillar el ebp

		:

	);
    register_ebp = (register_ebp - (int)current()) + (int)(uson);
	son->kernel_esp = register_ebp; //añadimos el espacio para el 0
	*(unsigned long*)(son->kernel_esp) = (unsigned long) &ret_from_fork;
	son->kernel_esp -=  sizeof(unsigned long);
	list_add_tail(&(son->list), &ready_queue);
	return son->PID;
}




void sys_exit(){  
	page_table_entry *process_PT = get_PT(current());
	for(int i = 0; i < NUM_PAG_DATA; i++) {
		free_frame(get_frame(process_PT, PAG_LOG_INIT_DATA + i));
		del_ss_pag(process_PT, PAG_LOG_INIT_DATA + i);	
	}
	list_add_tail(&(current()->list),&free_queue);
	current()->PID = -1;
	sched_next_rr();
}


int sys_gettime(){
	return zeos_ticks;	
}

int sys_get_stats(int pid, struct stats *st){
    if (pid < 0) return -EINVAL;
    if (!access_ok(VERIFY_WRITE, st, sizeof(struct stats))) return -EFAULT; 
    for (int i = 0; i < NR_TASKS; ++i){
        if (task[i].task.PID == pid){
            task[i].task.task_stats.remaining_ticks = remaining_quantum;
            copy_to_user(&task[i].task.task_stats, st, sizeof(struct stats));
            return 0;
        }
    }
    return -ESRCH;
}
